import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lazyloadingsecondchild',
  templateUrl: './lazyloadingsecondchild.component.html',
  styleUrls: ['./lazyloadingsecondchild.component.scss']
})
export class LazyloadingsecondchildComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
