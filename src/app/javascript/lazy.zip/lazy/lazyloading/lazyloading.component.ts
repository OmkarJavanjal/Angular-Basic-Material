import { Component, OnInit } from '@angular/core';
import { LazyloadingfirstchildComponent } from '../lazyloadingfirstchild/lazyloadingfirstchild.component';
import { LazyloadingsecondchildComponent } from '../lazyloadingsecondchild/lazyloadingsecondchild.component';
import {
  Router,
  NavigationEnd,
  ActivatedRoute
  } from '@angular/router';
  
@Component({
  selector: 'app-lazyloading',
  templateUrl: './lazyloading.component.html',
  styleUrls: ['./lazyloading.component.scss']
})
export class LazyloadingComponent implements OnInit {
public currentComponent;
  constructor( private router: Router,) { }

  ngOnInit() {
    console.log('this.router.url', this.router.url);
    if( this.router.url =='/lazyloadingfirstChild'){
this.currentComponent = LazyloadingfirstchildComponent;
    }
  }

}
