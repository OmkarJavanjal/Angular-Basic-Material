import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lazyloadingfirstchild',
  templateUrl: './lazyloadingfirstchild.component.html',
  styleUrls: ['./lazyloadingfirstchild.component.scss']
})
export class LazyloadingfirstchildComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
