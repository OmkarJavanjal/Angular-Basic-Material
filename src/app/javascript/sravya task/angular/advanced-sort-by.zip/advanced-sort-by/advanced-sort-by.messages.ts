sl_tr_start();
export const HOTEL_SORT_BY_MESSAGES = {
    'hoteloffers.distance': 'Distance',

};
sl_tr_end();
