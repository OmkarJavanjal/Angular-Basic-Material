import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvancedSortByComponent } from './advanced-sort-by.component';

describe('AdvancedSortByComponent', () => {
  let component: AdvancedSortByComponent;
  let fixture: ComponentFixture<AdvancedSortByComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdvancedSortByComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvancedSortByComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
