import { Component, OnInit } from '@angular/core';
import {HOTEL_SORT_BY_MESSAGES} from './advanced-sort-by.messages';


@Component({
  selector: 'advanced-sort-by',
  templateUrl: './advanced-sort-by.component.html',
  styleUrls: ['./advanced-sort-by.component.scss']
})
export class AdvancedSortByComponent implements OnInit {
clicked;
click;
messages = HOTEL_SORT_BY_MESSAGES;
values :any = [

]
  constructor() { }

  ngOnInit() {
  }
  distanceBtn() {
    this.clicked = !this.clicked;
  }
  brandBtn(){
    this.click = !this.click;
  }
onItemChange (event:any){
  this.clicked =event.target.value;
  console.log("hello",this.clicked);
}

}
