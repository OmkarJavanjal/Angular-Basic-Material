import { Component, TemplateRef } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

@Component({
    selector: 'my-modals',
  templateUrl: './modals.component.html',
  styleUrls: [ './modals.component.css' ]
})

/* This is a component which we pass in modal*/
export class ModalContentComponent {
  title: string;
  closeBtnName: string;
  list: any[] = [];
 initialState:any;
  constructor(public bsModalRef: BsModalRef) {}
 
  ngOnInit() {
    this.list.push('PROFIT!!!');  
    if(this.initialState){
       console.log('initialState--', this.initialState);
    }
  }
}