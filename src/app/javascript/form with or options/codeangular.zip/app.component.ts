import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from './app.service';
import { NG_VALIDATORS,Validator,
           Validators,AbstractControl,ValidatorFn } from '@angular/forms';
import swal  from 'sweetalert2';

//@author Chandra Bhushan Tripathi

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[AppService]
})
export class AppComponent {
 data:any={};
    registerdata:any;
    lname:any;
    ssn:any;
    zipcode:any;
    congrats:any
    
    constructor(private appService:AppService, private router:Router){}
    ngOnInit() { }
        submitted = false;
     
   //-------------------onSubmit function for validations--------------------------------
    
    onSubmit() { 
        this.submitted = true; }
  

   //----------------------postUser function suscribing service----------------------------- 
    postForm(valid){
      
       this.appService.postUsers(valid).subscribe((data)=>{
         this.congrats=data
       })
    }

}

