import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable , of} from 'rxjs'

//@author Chandra Bhushan Tripathi

@Injectable()
export class AppService {

	url:string='http://localhost:8000';

  constructor(private http:Http) { }

   postUsers(data:any){
   	console.log(data);
   	let success = "Success Full Congrats"
  	return of(success);
  }

}